const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

// Sample data - Represented as an array of objects
const componentData = [
    { code: "A", price: 10.28, part: "LED Screen" },
    { code: "B", price: 24.07, part: "OLED Screen" },
    { code: "C", price: 33.30, part: "AMOLED Screen" },
    { code: "D", price: 25.94, part: "Wide-Angle Camera" },
    { code: "E", price: 32.39, part: "Ultra-Wide-Angle Camera" },
    { code: "F", price: 18.77, part: "USB-C Port" },
    { code: "G", price: 15.13, part: "Micro-USB Port" },
    { code: "H", price: 20.00, part: "Lightning Port" },
    { code: "I", price: 42.31, part: "Android OS" },
    { code: "J", price: 45.00, part: "iOS OS" },
    { code: "K", price: 45.00, part: "Metallic Body" },
    { code: "L", price: 30.00, part: "Plastic Body" }
];

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Route to create an order
app.post('/orders', (req, res) => {
    const { components } = req.body;
    
    // Find components in the data and calculate total price and assemble parts
    let totalPrice = 0;
    const parts = [];
    components.forEach(componentCode => {
        const component = componentData.find(item => item.code === componentCode);
        if (component) {
            totalPrice += component.price;
            parts.push(component.part);
        }
    });

    // Response object
    const response = {
        order_id: "some-id", // You can generate a unique ID here
        total: totalPrice,
        parts: parts
    };

    res.json(response);
});

// Export the app for testing
module.exports = app;

// Start server if not in test environment
if (require.main === module) {
    app.listen(PORT, () => {
        console.log(`Server is running on port ${PORT}`);
    });
}
