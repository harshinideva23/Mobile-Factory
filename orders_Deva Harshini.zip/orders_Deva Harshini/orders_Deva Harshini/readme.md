# Phone Order API

This project implements an API to create orders for phones based on a list of component codes. It calculates the total price and assembles the parts of the phone based on the provided component codes.

## How it Works

The API is built using Node.js and Express.js. It exposes a single endpoint to create orders:

- `POST /orders`: Accepts a JSON payload containing a list of component codes. It calculates the total price and assembles the parts of the phone based on the provided component codes.

## Instructions to Run the Project

1. **Install Node.js**: Make sure you have Node.js installed on your system. You can download and install it from [here](https://nodejs.org/).

2. **Clone the Repository**: Clone this repository to your local machine.

    ```bash
    git clone https://github.com/your-username/phone-order-api.git
    ```

3. **Install Dependencies**: Navigate to the project directory and install the dependencies using npm.

    ```bash
    cd phone-order-api
    npm install
    ```

4. **Start the Server**: Run the following command to start the server.

    ```bash
    npm start
    ```

    This will start the server at `http://localhost:3000`.

5. **Testing the API**: You can test the API using tools like Thunder Client, Postman, or by running unit tests.

    - **Thunder Client**: Configure Thunder Client to send POST requests to `http://localhost:3000/orders` with a JSON payload containing a list of component codes. For example:
    
      ```json
      {
        "components": ["I", "A", "D", "F", "K"]
      }
      ```

    - **Postman**: Set up a similar request in Postman and send it to `http://localhost:3000/orders`.

    - **Unit Tests**: Run the provided unit tests using Jest to ensure the API works as expected.

      ```bash
      npm test
      ```

## API Usage

### Create an Order

**POST /orders**

Creates an order for a phone based on a list of component codes.

#### Request Body

```json
{
  "components": ["I", "A", "D", "F", "K"]
}
### Response Body

```json
{
  "order_id": "some-id",
  "total": 142.3,
  "parts": [
    "LED Screen",
    "Wide-Angle Camera",
    "USB-C Port",
    "Android OS",
    "Metallic Body"
  ]
}
