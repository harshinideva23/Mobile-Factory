const request = require('supertest');
const app = require('./app');

describe('POST /orders', () => {
    test('It should respond with order details', async () => {
        const requestBody = {
            components: ['A', 'B', 'D'] // Sample component codes
        };

        const response = await request(app)
            .post('/orders')
            .send(requestBody)
            .expect('Content-Type', /json/)
            .expect(200);

        expect(response.body).toHaveProperty('order_id');
        expect(response.body).toHaveProperty('total');
        expect(response.body).toHaveProperty('parts');
        expect(response.body.parts.length).toBe(3); // Assuming all components are found in the data
    });

    test('It should handle missing components gracefully', async () => {
        const requestBody = {
            components: ['Z'] // Non-existing component code
        };

        const response = await request(app)
            .post('/orders')
            .send(requestBody)
            .expect('Content-Type', /json/)
            .expect(200);

        expect(response.body).toHaveProperty('order_id');
        expect(response.body.total).toBe(0); // No components found, total should be 0
        expect(response.body.parts.length).toBe(0); // No components found, parts array should be empty
    });
});
